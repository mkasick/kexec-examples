#!/sbin/sh

append="$1"; shift

for arg in `cat /proc/cmdline`; do
	case "$arg" in
	bootmode=*)
		;;
	*)
		case "$cmdline" in
		"")
			cmdline="$arg" ;;
		*)
			cmdline="$cmdline $arg" ;;
		esac
	esac
done

/tmp/kexec "--append=$cmdline $append" "$@"
