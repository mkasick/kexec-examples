#!/sbin/sh

cmdline=`cat /proc/cmdline`
/tmp/kexec "--append=$cmdline" "$@"
