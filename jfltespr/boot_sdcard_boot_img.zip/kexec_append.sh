#!/sbin/sh

append="$1"; shift

for arg in `cat /proc/cmdline`; do
	case "$arg" in
	sysscope=*|androidboot.boot_recovery=*|androidboot.check_recovery_condition=*)
		;;
	*)
		case "$cmdline" in
		"")
			cmdline="$arg" ;;
		*)
			cmdline="$cmdline $arg" ;;
		esac
	esac
done

/tmp/kexec "--append=$cmdline $append" "$@"
